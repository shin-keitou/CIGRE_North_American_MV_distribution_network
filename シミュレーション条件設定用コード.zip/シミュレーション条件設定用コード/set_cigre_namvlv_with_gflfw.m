

%SIの容量とLPFの設定
Pnom=[400e3,400e3,400e3,400e3,400e3,400e3,400e3];
Qnom=0;
%IBR一次側電圧
Vinv=600;
%IBR二次次側電圧
Vdis=12.47e3;
%系統周波数
rate_freq=60;
numSI=size(Pnom);
pu2HC=zeros(1,numSI(1,2));
pz=zeros(1,numSI(1,2));
for i=1:numSI(1,2)
    pu2HC(1,i)=1/(Pnom(1,i)/((Vinv)^2))/(rate_freq*2*pi);
    pz(1,i)=Pnom(1,i)/((Vinv)^2);
end
%直流電圧
DCvoltage=2000;


L_SI_pu=[1.05,1.05,1.38,1.15,1.31,1.21,1.00];
C_SI_pu=[0,0,0,0,0,0,0,0];
R_SI_pu=[0.001,0.001,0.001,0.001,0.001,0.001,0.001];

L_SI=zeros(1,numSI(1,2));
C_SI=zeros(1,numSI(1,2));
R_SI=zeros(1,numSI(1,2));

for i=1:numSI(1,2)
    L(1,i)=L_SI_pu(1,i)*pu2HC(1,i);
    C(1,i)=C_SI_pu(1,i)*pu2HC(1,i);
    R(1,i)=R_SI_pu(1,i)*pu2HC(1,i)*(rate_freq*2*pi);
end
% 
C(1,1)=0;
C_SI_pu=0;
% %Volt/var制御適用する場合
% vvlimit=0.44;
% vvslope=0.44/0.02;
% deadband=0.02;

%PLL
KpPLL=100;
KiPLL=9000;
PLL2=1/(2*pi*25);

%Frequency/watt
k=[-2,-1.5,-1.75,-1.2,-2.0,-1.5,-1.75];
%初期出力(IBR容量ベースのpu)
P0=[0.6,0.7,0.3,0.4,0.7,0.5,0.5];

%電流制御のPIゲイン
Kp=1;
Kiq=[300,300,300,300,300,300,300];
Kid=[300,300,300,300,300,300,300];

Ts=2e-6; %PWMのサンプル周期
Tchange=0.2;%0.5秒後にIBRに出力開始スタート用

%発生擾乱設定
jstart=4;
ffluc=49.7;
ffluc=49.5;
vfluc=1.0;
vfluc=0.9;
vsetsg=1.0;
through_rate=15;

% residential_load = zeros(14,3);
% industrial_load = zeros(14,3);
% load_pf = zeros(14,2);
%エクセルデータから負荷の初期値と力率を取得
load_size = readmatrix('cigre_namvlv_load.xlsx');
load_pf = readmatrix('cigre_namvlv_load_pf.xlsx');
residential_load = load_size(:, [1 3 5])*1e3;
industrial_load = load_size(:, [2 4 6])*1e3;
residential_load_3ph = zeros(size(load_size,1),1);
industrial_load_3ph = zeros(size(load_size,1),1);
load_bus = zeros(size(load_size,1),2);
%単相データから平均値を取って三相データに変換
for i = 1 : size(load_size,1)
    residential_load_3ph(i,1) = sum (residential_load(i,:),2)*load_pf(i,1);
    residential_load_3ph(i,2) = sqrt((sum (residential_load(i,:),2))^2-(residential_load_3ph(i,1))^2);
    industrial_load_3ph(i,1) = sum (industrial_load(i,:),2)*load_pf(i,2);
    industrial_load_3ph(i,2) = sqrt((sum (industrial_load(i,:),2))^2-(industrial_load_3ph(i,1))^2);    
    load_bus(i,1) = real(residential_load_3ph(i,1)) + real(industrial_load_3ph(i,1));
    load_bus(i,2) = real(residential_load_3ph(i,2)) + real(industrial_load_3ph(i,2));
end
%この値をエクセルに負荷の大きさとして入力
load_bus_4excel = load_bus/10e6;

%IBRの容量と初期出力を決定
ibr_va=[1.5,1.0,0.4,1.2,0.6,0.8,1.2]*1e6/10e6;
P0_pu = zeros (7,1);
for i = 1 : 7
    %この値をエクセルに出力の大きさとして入力
    P0_pu(i,1) = -1*ibr_va(1,i)*P0(1,i)*10;
end


Pbase = 10e6;
z_base=((Vdis)^2)/Pbase;

r_pkm = 0.282;
l_pkm = 0.703;
rl_pkm = [0.282 0.703]; %ohm/km
%各ラインの距離データ
line_length = [1.2 1.0 0.61 0.56 1.54 0.24 1.67 0.32 0.77 0.33 0.49 1.30];
rl_pu = zeros(12,2);
%ラインインピーダンス　この値をエクセルに入力
for i = 1 : 12
    rl_pu(i,1) = rl_pkm(1,1)*line_length(1,i)/z_base;
    rl_pu(i,2) = rl_pkm(1,2)*line_length(1,i)/z_base;
end
tr_va = 2000e3;

%IBR変圧器のインピーダンス
rl_tr_pu = [0.02 0.16];
rl_tr_pu = rl_tr_pu*(((Vdis)^2)/2000e3)/z_base;
