function[A_,B_,j,newpn]=hankel_apx_DC(fn,pn,a,b,fflag)
j=ones(1,fn);
A_=zeros(fn,max(pn)+1);
B_=zeros(fn,max(pn)+1);
newpn=pn;
for i=1:fn
    if pn(1,i)>0        
        tranfun=tf(b(i,:),a(i,:));%(分子，分母)
        opts = balredOptions('Offset',0.0001,'StateProjection','MatchDC');
        opts = balredOptions('Offset',0.1,'StateProjection','MatchDC');
        opts = balredOptions('Offset',0.01,'StateProjection','MatchDC');
        opts = balredOptions('Offset',0.001,'StateProjection','MatchDC');
        % opts = balredOptions('Offset',0.01,'StateProjection','MatchDC','TimeIntervals',[0 1]);
        if fflag==0
            opts = balredOptions('Offset',0.001,'StateProjection','MatchDC','TimeIntervals',[0 0.5]);
            % opts = balredOptions('Offset',0.001,'StateProjection','MatchDC','TimeIntervals',[0 1]);
            % opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 0.5]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 1]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 10]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 5]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 0.05]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 1.0]);
            % opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 1.5]);
            % opts = balredOptions('Offset',0.001,'StateProjection','Truncate');
            % opts = balredOptions('Offset',0.001,'StateElimMethod','Truncate','TimeIntervals',[0 0.5]);
        else
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 0.5]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 10]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 5]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 0.05]);
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 1.0]);
            % opts = balredOptions('Offset',0.001,'StateProjection','Truncate','TimeIntervals',[0 1.5]);
            % opts = balredOptions('Offset',0.001,'StateProjection','Truncate');
            % opts = balredOptions('Offset',0.001,'StateElimMethod','Truncate','TimeIntervals',[0 0.5]);
        end
        red_stable_check=0;
        ori_stable_check=0;
        rsys=balred(tranfun,pn(1,i),opts);
        [num,den] = tfdata(rsys);
        Bk_=cell2mat(num);
        Ak_=cell2mat(den);
        rootc=roots(Ak_);        
        rooto=roots(a(i,:));
        if max(real(rootc))>0
            red_stable_check=1;
        end
        if max(real(rooto))>0
            ori_stable_check=1;
        end
        if red_stable_check==1 && red_stable_check~=ori_stable_check
            clear num den Ak_ Bk_
            opts = balredOptions('Offset',0.001,'StateProjection','Truncate');
            rsys=balred(tranfun,pn(1,i),opts);
            [num,den] = tfdata(rsys);
            Bk_=cell2mat(num);
            Ak_=cell2mat(den);
        end
        [row col]=size(Ak_);
        if max(pn)==pn(1,i)
            if pn(1,i)>(col-1)
                A_(i,(pn(1,i)-(col-1))+1:max(pn)+1)=Ak_;
                B_(i,(pn(1,i)-(col-1))+1:max(pn)+1)=Bk_;
                newpn(1,i)=col-1;
            else
                A_(i,:)=Ak_;
                B_(i,:)=Bk_;
            end
        else
            newpn(1,i)=col-1;
            insert_zeroA=zeros(1,max(pn)-newpn(1,i));
            insert_zeroB=zeros(1,max(pn)-newpn(1,i));
            A_(i,:)=[insert_zeroA Ak_];
            B_(i,:)=[insert_zeroB Bk_];            
        end
        j(1,i)=0;%値がある場合は0
        clear Ak_ Bk_
    end
end
difpn=max(pn)-max(newpn);
A_=A_(:,difpn+1:(max(pn)+1));
B_=B_(:,difpn+1:(max(pn)+1));
% box_A_=A_;
% box_B_=B_;
% A_=zeros(fn,max(newpn)+1);
% B_=zeros(fn,max(newpn)+1);
% [row,col]=size(box_A_);
% for i=1:row
%     A_=box_A_(i,difpn+1:(max(pn)+1));
%     B_=box_B_(i,difpn+1:(max(pn)+1));
% end

