function[mtrx,dim_tr]=make_mtrx_for3(fn,a1,a2,a3)
r=zeros(1,fn);
dim_tr=zeros(1,fn);

[r(1,1),dim_tr(1,1)]=size(a1);
[r(1,2),dim_tr(1,2)]=size(a2);
[r(1,3),dim_tr(1,3)]=size(a3);
max_dim=max(dim_tr)-1;
mtrx=zeros(fn,max_dim+1);
flag=0;
while(flag==0)
    if max_dim==dim_tr(1,1)-1
        mtrx(1,:)=a1;
        insert_zero=zeros(1,max_dim-dim_tr(2)+1);
        mtrx(2,:)=[insert_zero a2];
        clear insert_zero
        insert_zero=zeros(1,max_dim-dim_tr(3)+1);
        mtrx(3,:)=[insert_zero a3];
        clear insert_zero
        flag=1;
        break;
    end
    if max_dim==dim_tr(1,2)-1
        mtrx(2,:)=a2;
        insert_zero=zeros(1,max_dim-dim_tr(1)+1);
        mtrx(1,:)=[insert_zero a1];
        clear insert_zero
        insert_zero=zeros(1,max_dim-dim_tr(3)+1);
        mtrx(3,:)=[insert_zero a3];
        clear insert_zero
        flag=1;
        break;
    end
    if max_dim==dim_tr(1,3)-1
        mtrx(3,:)=a3;
        insert_zero=zeros(1,max_dim-dim_tr(1)+1);
        mtrx(1,:)=[insert_zero a1];
        clear insert_zero
        insert_zero=zeros(1,max_dim-dim_tr(2)+1);
        mtrx(2,:)=[insert_zero a2];
        clear insert_zero
        flag=1;
        break;
    end
end

dim_tr=dim_tr-ones(1,fn);
end
