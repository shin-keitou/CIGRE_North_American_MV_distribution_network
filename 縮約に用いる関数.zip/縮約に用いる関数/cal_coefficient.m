function[k_,b]=cal_coefficient(fn,dim_a,dim_b,a,b,f2flag)

k_=zeros(1,fn);
for i=1:fn
    k_(1,i)=b(i,max(dim_b)+1)/a(i,max(dim_a)+1);
    if f2flag==1
        b(i,:)=b(i,:)/k_(1,i);
    end
end