function[newidvd,newidvq,newidf1,newidf2,newiqvd,newiqvq,newiqf1,newiqf2]=i_reduce_order_hankel_tf_fw(dim,flag,idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2)
% pn=dim
dimset=dim;
fn=1;
reduceflag=1;
fflag=0;
[row col]=size(idvd(2,:));
if col<(dimset+1)
    idvdd=idvd(2,:);
    idvdn=idvd(1,:);
else
    dimset=dim;
    if flag(1,1)==0
        [idvdd,idvdn]=hankel_apx_only_reduce_fnoDC(fn,dimset,idvd(2,:),idvd(1,:),reduceflag,fflag);
    else
        dimset=flag(2,1);
        [idvdd,idvdn]=hankel_apx_only_reduce_fnoDC(fn,dimset,idvd(2,:),idvd(1,:),reduceflag,fflag);
    end
end

dimset=dim;
[row col]=size(idvq(2,:));
if col<(dimset+1)
    idvqd=idvq(2,:);
    idvqn=idvq(1,:);
else
    dimset=dim;
    if flag(1,2)==0
        [idvqd,idvqn]=hankel_apx_only_reduce_fnoDC(fn,dimset,idvq(2,:),idvq(1,:),reduceflag,fflag);
    else
        dimset=flag(2,2);
        [idvqd,idvqn]=hankel_apx_only_reduce_fnoDC(fn,dimset,idvq(2,:),idvq(1,:),reduceflag,fflag);
    end    
end
fflag=1;
dimset=dim;
[row col]=size(idf1(2,:));
if col<(dimset+1)
    idf1d=idf1(2,:);
    idf1n=idf1(1,:);
else
    dimset=dim;
    if flag(1,3)==0
        [idf1d,idf1n]=hankel_apx_only_reduce_fnoDC(fn,dimset,idf1(2,:),idf1(1,:),reduceflag,fflag);
    else
        dimset=flag(2,3);
        [idf1d,idf1n]=hankel_apx_only_reduce_fnoDC(fn,dimset,idf1(2,:),idf1(1,:),reduceflag,fflag);
    end
end
fflag=0;
dimset=dim;
[row col]=size(idf2(2,:));
if col<(dimset+1)
    idf2d=idf2(2,:);
    idf2n=idf2(1,:);
else
    dimset=dim;
    if flag(1,4)==0
        % [idf2d,idf2n]=hankel_apx_only_reduce_fnoDC(fn,dimset,idf2(2,:),idf2(1,:),reduceflag,fflag);
        [idf2d,idf2n]=hankel_apx_only_reduce_DC(fn,dimset,idf2(2,:),idf2(1,:),reduceflag,fflag);
    else
        dimset=flag(2,4);
        % [idf2d,idf2n]=hankel_apx_only_reduce_fnoDC(fn,dimset,idf2(2,:),idf2(1,:),reduceflag,fflag);
         [idf2d,idf2n]=hankel_apx_only_reduce_DC(fn,dimset,idf2(2,:),idf2(1,:),reduceflag,fflag);
    end    
end

dimset=dim;
[row col]=size(iqvd(2,:));
if col<(dimset+1)
    iqvdd=iqvd(2,:);
    iqvdn=iqvd(1,:);
else
    dimset=dim;
    if flag(1,5)==0
        [iqvdd,iqvdn]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqvd(2,:),iqvd(1,:),reduceflag,fflag);
    else
        dimset=flag(2,5);
        [iqvdd,iqvdn]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqvd(2,:),iqvd(1,:),reduceflag,fflag);
    end    
end

dimset=dim;
[row col]=size(iqvq(2,:));
if col<(dimset+1)
    iqvqd=iqvq(2,:);
    iqvqn=iqvq(1,:);
else
    dimset=dim;
    if flag(1,6)==0
        [iqvqd,iqvqn]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqvq(2,:),iqvq(1,:),reduceflag,fflag);
    else
        dimset=flag(2,6);
        [iqvqd,iqvqn]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqvq(2,:),iqvq(1,:),reduceflag,fflag);
    end    
end
fflag=1;
dimset=dim;
[row col]=size(iqf1(2,:));
if col<(dimset+1)
    iqf1d=iqf1(2,:);
    iqf1n=iqf1(1,:);
else
    dimset=dim;
    if flag(1,7)==0
        [iqf1d,iqf1n]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqf1(2,:),iqf1(1,:),reduceflag,fflag);
    else
        dimset=flag(2,7);
        [iqf1d,iqf1n]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqf1(2,:),iqf1(1,:),reduceflag,fflag);
    end    
end
fflag=0;
dimset=dim;
[row col]=size(iqf2(2,:));
if col<(dimset+1)
    iqf2d=iqf2(2,:);
    iqf2n=iqf2(1,:);
else
    dimset=dim;
    if flag(1,8)==0
        [iqf2d,iqf2n]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqf2(2,:),iqf2(1,:),reduceflag,fflag);
    else
        dimset=flag(2,8);
        [iqf2d,iqf2n]=hankel_apx_only_reduce_fnoDC(fn,dimset,iqf2(2,:),iqf2(1,:),reduceflag,fflag);
    end    
end


newidvd=[idvdn;idvdd];
newidvq=[idvqn;idvqd];
newidf1=[idf1n;idf1d];
newidf2=[idf2n;idf2d];

newiqvd=[iqvdn;iqvdd];
newiqvq=[iqvqn;iqvqd];
newiqf1=[iqf1n;iqf1d];
newiqf2=[iqf2n;iqf2d];
