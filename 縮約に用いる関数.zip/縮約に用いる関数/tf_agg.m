function[a,b,k_]=tf_agg(fn,pn,jte,Ate_,Bte_,k_,f2flag)
amtrx_=zeros(1,max(pn)+1);
bmtrx_=zeros(1,max(pn)+1);
% num_si=find(jt);
% for i=1:fn
%     if jte(1,i)==0
%         amtrx_(i,:)=Ate_(i,:)/(Ate_(i,1+max(pn)-pn(i))); %分母の0次元目の値を1にする
%         %         rtscheck1=roots(a1)
%         bmtrx_(i,:)=Bte_(i,:)/(Ate_(i,1+max(pn)-pn(i))); %分母を割った値で分子も割る
%     else
%         amtrx_(i,max(pn)+1)=1;%分担がない伝達関数を0/1とする
%         bmtrx_(i,max(pn)+1)=0;
%     end
% end
if f2flag==1
    kf2=zeros(1,fn);
    for i=1:fn
        if Ate_(i,max(pn)+1)~=0
            kf2(1,i)=Bte_(i,max(pn)+1)/Ate_(i,max(pn)+1);
            Bte_(i,:)=Bte_(i,:)/kf2(1,i); 
            k_(1,i)=kf2(1,i)*k_(1,i);
        end
    end
end

    
for i=1:fn
    if jte(1,i)==0
        amtrx_(i,:)=Ate_(i,:)/(Ate_(i,1+max(pn))); %分母の0次元目の値を1にする
        %         rtscheck1=roots(a1)
        bmtrx_(i,:)=Bte_(i,:)/(Ate_(i,1+max(pn))); %分母を割った値で分子も割る
    else
        amtrx_(i,max(pn)+1)=1;%分担がない伝達関数を0/1とする
        bmtrx_(i,max(pn)+1)=0;
    end
end



a_=conv(amtrx_(1,:),amtrx_(2,:));
if fn>=3
    a=conv(a_,amtrx_(3,:));
else
    a=a_;
end

for i=1:fn-1
    if i==1
        b_1=conv(bmtrx_(1,:),amtrx_(2,:));
        b_2=conv(bmtrx_(2,:),amtrx_(1,:));
    else
        b_1=conv(b_,amtrx_(3,:));
        b_2=conv(bmtrx_(3,:),a_);
    end
    [rowfp1,colfp1] = size(b_1);
    [rowfp2,colfp2] = size(b_2);
    if colfp1>=colfp2
        j=colfp1-colfp2;
        b=zeros(1,colfp1);
        for ii=1:colfp1-j
            b(1,colfp1-ii+1)=b_1(1,colfp1-ii+1)+b_2(1,colfp2-ii+1);
        end
        for ii=1:j
            b(1,ii)=b_1(1,ii);
        end
    else
        j=colfp2-colfp1;
        b=zeros(1,colfp2);
        for ii=1:colfp2-j
            b(1,colfp2-ii+1)=b_1(1,colfp1-ii+1)+b_2(1,colfp2-ii+1);
        end
        for ii=1:j
            b(1,ii)=b_2(1,ii);
        end
    end
    b_=b;
end

% [rowfp1,colfp1] = size(b);
% [rowfp2,colfp2] = size(a);
% kall=0;
% gainall=0;
if f2flag==0
%     elmi_tfgain_box=[jte;k_];
%     [row,col]=size(k_);
%     for i=1:col
%         if k_(1,i)==0
%             elmi_tfgain_box(:,i)=[];
%         end
%     end
    elmi_tfgain_box=[jte;k_];
    elmi_tfgain=sum(prod(elmi_tfgain_box)); %排除された伝達関数のゲインの総和
    if elmi_tfgain~=0
        allgain=sum(k_); %集約する伝達関数のゲインの総和
        % for i=1:fn
        %     box=jte(1,i)*k_(1,i);
        %     kall=kall+box;
        %     gainall=gainall+k_(1,i);
        % end
        % kg=b(1,colfp1)/a(1,colfp2);
        % b= gainall/kg*b;
        if (allgain-elmi_tfgain)~=0
            b=b*allgain/(allgain-elmi_tfgain);  
        end
    end
else
    b=b/(fn-sum(jte));
end
% flag=0;
[row,col]=size(a);
ii=col;
% newa=a;
% newb=b;
zero_count_a=0;
for i=1:ii
    if a(1,i)==0
        zero_count_a=zero_count_a+1;
    else
        zero_count_a=zero_count_a+1;
        break;
    end
end
a=a(zero_count_a:col);
b=b(zero_count_a:col);
% while flag==0
%     newa=a;
%     newb=b;
%     for i=1:ii
%         if newa(1,i)==0
%             zero_count_a=zero_count_a+1;
%         else
%             ii=0;
%         end
%     end
%     a=newa(zero_count_a:col);
%     b=newb(zero_count_a:col);
%     zero_count_a=
%     if (newa(1,1)==0)&&(newb(1,1)==0)
%         [row,col]=size(a);
%         a=newa(2:col);
%         b=newb(2:col);
%     else
%         flag=1;
%     end
% end



% if f2flag==1
%     b=b/fn;
% end

end
