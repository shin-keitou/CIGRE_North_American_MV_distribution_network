function[N2,D2,cd]=trsf_make(Ans)
sAns=simplifyFraction(Ans,'Expand',true);
[N,D] = numden(sAns);
D2=sym2poly(D);
N2=sym2poly(N);
% SlvD2=roots(D2);
[ln,cn]=size(N2);
[ld,cd]=size(D2);
difc=cd-cn;
if difc>0
    temp=zeros(1,cd);
    for i=1:cd
        if i<=difc
            temp(1,i)=0;
        else
            temp(1,i)=N2(1,i-difc);
        end        
    end
    N2=temp;
end
% Nmax=max(N2)
Gtrsf=[N2;D2];
end

