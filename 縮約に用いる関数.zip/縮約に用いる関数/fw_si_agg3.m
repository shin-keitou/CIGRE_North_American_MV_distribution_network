function[idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2,kpfw]=fw_si_agg3(fn,dim,math_1,math_2,math_3,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,kpfw)
 %dsxis : 1,qaxis : 2
f2flag=0;
fflag=0;
mathcellall=cell(2,6);
for i=1:4
    kp_temp=kpfw;
    if i==3
        fflag=1;        
    elseif  i==4
        f2flag=1;
        kp_temp=kpfw;    
    end
    [mathcellall{1,i},kp_temp]=each_math_agg(fn,dim,math_1{1,i},math_2{1,i},math_3{1,i},tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,1,kp_temp,f2flag,fflag);
    [mathcellall{2,i},kp_temp]=each_math_agg(fn,dim,math_1{2,i},math_2{2,i},math_3{2,i},tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,2,kp_temp,f2flag,fflag);

    f2flag=0;
    fflag=0;
    if i==4        
        kpfw=kp_temp;    
    end
end

idvd=cell2mat(mathcellall{1,1});
idvq=cell2mat(mathcellall{1,2});
idf1=cell2mat(mathcellall{1,3});
idf2=cell2mat(mathcellall{1,4});
iqvd=cell2mat(mathcellall{2,1});
iqvq=cell2mat(mathcellall{2,2});
iqf1=cell2mat(mathcellall{2,3});
iqf2=cell2mat(mathcellall{2,4});
end