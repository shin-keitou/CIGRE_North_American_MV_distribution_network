function[GV1dd,GV1dq,GF1d,GF2d,GV1qd,GV1qq,GF1q,GF2q]=mat2syms(dvd,dvq,df1,df2,qvd,qvq,qf1,qf2)
syms s
szd=size(dvd(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+dvd(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+dvd(2,szd(1,2)+1-i)*s^(i-1);
end
GV1dd = (Fsn/Fsd);

szd=size(dvq(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+dvq(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+dvq(2,szd(1,2)+1-i)*s^(i-1);
end
GV1dq = (Fsn/Fsd);


szd=size(df1(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+df1(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+df1(2,szd(1,2)+1-i)*s^(i-1);
end
GF1d = (Fsn/Fsd);

szd=size(df2(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+df2(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+df2(2,szd(1,2)+1-i)*s^(i-1);
end
GF2d = (Fsn/Fsd);

szd=size(qvd(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+qvd(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+qvd(2,szd(1,2)+1-i)*s^(i-1);
end
GV1qd = (Fsn/Fsd);

szd=size(qvq(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+qvq(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+qvq(2,szd(1,2)+1-i)*s^(i-1);
end
GV1qq = (Fsn/Fsd);

szd=size(qf1(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+qf1(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+qf1(2,szd(1,2)+1-i)*s^(i-1);
end
GF1q = (Fsn/Fsd);

szd=size(qf2(2,:));
Fsn=0;
Fsd=0;
for i=1:szd(1,2)
    Fsn=Fsn+qf2(1,szd(1,2)+1-i)*s^(i-1);
    Fsd=Fsd+qf2(2,szd(1,2)+1-i)*s^(i-1);
end
GF2q = (Fsn/Fsd);