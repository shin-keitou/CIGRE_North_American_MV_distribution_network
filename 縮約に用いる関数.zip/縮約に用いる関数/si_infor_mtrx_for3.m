function[nsi,aggts_in_num]=si_infor_mtrx_for3(fn,all_si_num,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num)
aggts_in_num=[tf1_in_si_num tf2_in_si_num tf3_in_si_num];
nsi=zeros(fn,all_si_num-1);
[row1 col1]=size(tf1_in_si_num);
for i=1:col1
    nsi(1,tf1_in_si_num(1,i))=1;
end

[row1 col1]=size(tf2_in_si_num);
for i=1:col1
    nsi(2,tf2_in_si_num(1,i))=1;
end

[row1 col1]=size(tf3_in_si_num);
for i=1:col1
    nsi(3,tf3_in_si_num(1,i))=1;
end
end