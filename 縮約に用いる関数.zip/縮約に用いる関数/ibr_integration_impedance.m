function[vdvd,vdvq,vdf1,vdf2,vqvd,vqvq,vqf1,vqf2,idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2]=ibr_integration_impedance(fnom,rpm,lpm,dvd,dvq,df1,df2,qvd,qvq,qf1,qf2,vd0,vq0,id0,iq0)
f = fnom;
Rl = rpm;
Ll = lpm;

pf=(vq0)/sqrt((vq0)^2+(vd0)^2);%vdq0はpu値

syms s
[GV1dd,GV1dq,GF1d,GF2d,GV1qd,GV1qq,GF1q,GF2q]=mat2syms(dvd,dvq,df1,df2,qvd,qvq,qf1,qf2);

%V1-V2 = I(R+L)とIBRの数式モデル
line_mata1=[1,0,Rl+Ll*s,-2*pi*f*Ll;0,1,2*pi*f*Ll,Rl+Ll*s;-GV1dd+pf*(-GV1qd), -GV1dq+pf*(-GV1qq),1,0;-GV1qd-pf*(-GV1dd), -GV1qq-pf*(-GV1dq),0,1];
line_mata2=[1,0,2*pi*Ll*iq0,0,;0,1,-2*pi*Ll*id0,0;0,0,GF1d,GF2d;0,0,GF1q,GF2q];

Trs=line_mata1\line_mata2;

[vdvd,vdvq,vdf1,vdf2,vqvd,vqvq,vqf1,vqf2,idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2]=extraction_each_G(Trs);

%極の確認用
% roots(vdvd(2,:))
% rts=roots(idf2(2,:));

end