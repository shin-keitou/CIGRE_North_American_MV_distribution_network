function[pn]=cal_dim_part(fn,dim,dim_a,y)
dima=zeros(1,fn);
y_all=0;
% for i=1:fn
%     dima(1,i) = dim_a(1,i)-1;
% end

tt=isnan(y);
for i=1:fn
  if tt(1,i)==1
       y(1,i)=max(y)*10;
  end
    y_all=y_all+y(1,i);
end
flag=0;


while flag==0
    y_ps=zeros(1,fn);
    pole_ps=zeros(1,fn);
    pole_percent=zeros(1,fn);
    pn=zeros(1,fn);
    for i=1:fn
        y_ps(1,i)=y(1,i)/y_all;%各伝達関数の全エネルギーの中の割合を算出
        pole_ps(1,i)=dim*y_ps(1,i);%各伝達関数の分担次数を算出
    end
    pole_ps_fix=fix(pole_ps);%ゼロ方向に丸め込み
    pn=fix(pole_ps);
    pole_ps=pole_ps-fix(pole_ps);
    for i=1:dim-sum(pole_ps_fix) %各伝達関数の分担次数の割り振り
        [rowfp1,colfp1]=max(pole_ps);%どちらの残りが多いか算出
        pn(1,colfp1)=pn(1,colfp1)+1;%次数割合が大きい伝達関数の担当の次数を１増やす
        pole_ps(1,colfp1)=pole_ps(1,colfp1)-1;%割り振った分残りの次数割合を減らす
    end

    adj_dim=dim_a-pn; %各伝達関数の次数と集約のための分担次数の比較

    if min(adj_dim)<=-1 %集約のための分担次数が基の伝達関数の次数より大きい場合
        dim=dim-1;%集約後の伝達関数を減らす
    else
        flag=1;%大丈夫だったらループを抜ける
    end
end
clear tt