function[mtrx,dim_tr]=make_mtrx(fn,a1,a2)
r=zeros(1,fn);
dim_tr=zeros(1,fn);

[r(1,1),dim_tr(1,1)]=size(a1);
[r(1,2),dim_tr(1,2)]=size(a2);
max_dim=max(dim_tr)-1;
mtrx=zeros(fn,max_dim+1);
if max_dim==dim_tr(1,2)-1
    insert_zero=zeros(1,max_dim-dim_tr(1)+1);
    mtrx(1,:)=[insert_zero a1];
    mtrx(2,:)=a2;
else
    mtrx(1,:)=a1;
    insert_zero=zeros(1,max_dim-dim_tr(2)+1);
    mtrx(2,:)=[insert_zero a2];
end
dim_tr=dim_tr-ones(1,fn);
end
