function[vdvd,vdvq,vdf1,vdf2,vqvd,vqvq,vqf1,vqf2,idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2]=ibr_integration_impedance_withld(fnom,Pz,Qz,zip_rate,frate,rpm,lpm,line_length,vdd,vdq,f1d,f2d,vqd,vqq,f1q,f2q,id0,iq0,vd0,vq0,idz0,iqz0)

f = fnom;
alpha=1e-2; %定PQ負荷の一次遅れ
Rl = rpm*line_length;
Ll = lpm*line_length;


pf=(vq0)/sqrt((vq0)^2+(vd0)^2);%vdq0はpu値


syms s
FsV2ddn=0;
FsV2ddd=0;
FsV2dqn=0;
FsV2dqd=0;
FsFdn=0;
FsFdd=0;
FsF2dfwn=0;
FsF2dfwd=0;


FsV2qdn=0;
FsV2qdd=0;
FsV2qqn=0;
FsV2qqd=0;
FsFqn=0;
FsFqd=0;
FsF2qfwn=0;
FsF2qfwd=0;


GFLvdd=vdd;
GFLvdq=vdq;
GFLf1d=f1d;
GFLf2dfw=f2d;


GFLvqd=vqd;
GFLvqq=vqq;
GFLf1q=f1q;
GFLf2qfw=f2q;


szd=size(GFLvdd);
for i=1:szd(1,2)
    FsV2ddn=FsV2ddn+GFLvdd(1,szd(1,2)+1-i)*s^(i-1);
    FsV2ddd=FsV2ddd+GFLvdd(2,szd(1,2)+1-i)*s^(i-1);
end
FsV2dd = FsV2ddn/FsV2ddd;
szd=size(GFLvdq);
for i=1:szd(1,2)
    FsV2dqn=FsV2dqn+GFLvdq(1,szd(1,2)+1-i)*s^(i-1);
    FsV2dqd=FsV2dqd+GFLvdq(2,szd(1,2)+1-i)*s^(i-1);
end
FsV2dq =  FsV2dqn/ FsV2dqd;
szd=size(GFLf1d);
for i=1:szd(1,2)
    FsFdn=FsFdn+GFLf1d(1,szd(1,2)+1-i)*s^(i-1);
    FsFdd=FsFdd+GFLf1d(2,szd(1,2)+1-i)*s^(i-1);
end
szd=size(GFLf2dfw);
for i=1:szd(1,2)
    FsF2dfwn=FsF2dfwn+GFLf2dfw(1,szd(1,2)+1-i)*s^(i-1);
    FsF2dfwd=FsF2dfwd+GFLf2dfw(2,szd(1,2)+1-i)*s^(i-1);
end

szd=size(GFLvqd);
for i=1:szd(1,2)
    FsV2qdn=FsV2qdn+GFLvqd(1,szd(1,2)+1-i)*s^(i-1);
    FsV2qdd=FsV2qdd+GFLvqd(2,szd(1,2)+1-i)*s^(i-1);
end
FsV2qd = FsV2qdn/FsV2qdd;
szd=size(GFLvqq);
for i=1:szd(1,2)
    FsV2qqn=FsV2qqn+GFLvqq(1,szd(1,2)+1-i)*s^(i-1);
    FsV2qqd=FsV2qqd+GFLvqq(2,szd(1,2)+1-i)*s^(i-1);
end
FsV2qq = FsV2qqn/FsV2qqd;
szd=size(GFLf1q);
for i=1:szd(1,2)
    FsFqn=FsFqn+GFLf1q(1,szd(1,2)+1-i)*s^(i-1);
    FsFqd=FsFqd+GFLf1q(2,szd(1,2)+1-i)*s^(i-1);
end
szd=size(GFLf2qfw);
for i=1:szd(1,2)
    FsF2qfwn=FsF2qfwn+GFLf2qfw(1,szd(1,2)+1-i)*s^(i-1);
    FsF2qfwd=FsF2qfwd+GFLf2qfw(2,szd(1,2)+1-i)*s^(i-1);
end


if sum(FsFdn)==0
    FsFd=0;
else
    FsFd=FsFdn/FsFdd;
end
FsF2d=FsF2dfwn/FsF2dfwd;

if sum(FsFqn)==0
    FsFq=0;
else
    FsFq=FsFqn/FsFqd;
end
FsF2q=FsF2qfwn/FsF2qfwd;

%下位バスの負荷の数式モデルと足し合わせ
lvdd = zip_rate(1,1)*Pz/vd0^2/3*2 - zip_rate(1,3)*idz0/vd0/(alpha*s+1);
lvdq = zip_rate(1,1)*Qz/vd0^2/3*2- zip_rate(1,3)*iqz0/vd0/(alpha*s+1);
lvqd = -zip_rate(2,1)*Qz/vd0^2/3*2 - zip_rate(2,3)*iqz0/vd0/(alpha*s+1);
lvqq = zip_rate(2,1)*Pz/vd0^2/3*2 + zip_rate(2,3)*idz0/vd0/(alpha*s+1);
GV1dd = FsV2dd + lvdd;
GV1dq = FsV2dq + lvdq;
GF1d = FsFd + Pz * (frate(1,1))/(alpha*s+1);
GF2d = FsF2d;

GV1qd = FsV2qd + lvqd;
GV1qq = FsV2qq + lvqq;
GF1q = FsFq + Qz * (frate(1,2))/(alpha*s+1);
GF2q = FsF2q;


line_mata1=[1,0,Rl+Ll*s,-2*pi*f*Ll;0,1,2*pi*f*Ll,Rl+Ll*s;-GV1dd+pf*(-GV1qd), -GV1dq+pf*(-GV1qq),1,0;-GV1qd-pf*(-GV1dd), -GV1qq-pf*(-GV1dq),0,1];
line_mata2=[1,0,2*pi*Ll*iq0,0,;0,1,-2*pi*Ll*id0,0;0,0,GF1d-pf*GF1q,GF2d;0,0,GF1q+pf*GF1d,GF2q];

Trs=line_mata1\line_mata2;
[vdvd,vdvq,vdf1,vdf2,vqvd,vqvq,vqf1,vqf2,idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2]=extraction_each_G(Trs);
%極確認用
% roots(vdvd(2,:))

end
