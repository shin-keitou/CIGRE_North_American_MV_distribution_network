function[y]=cal_impulse(kk,a,b)
tt=1000;
tt=100;
tt=10;
g=tf(kk*b,a);
[y_,t]=impulse(g,0:1e-4:tt);
[t_height,col] = size(y_);
% nrm=norm(y1);
% y=norm(y_)/t_height;

y=sum(abs(y_))/t_height;
end