function[a,b,kpn]=fw_si_agg_each_test_for3(fn,dim,tf1,tf2,tf3,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,dq,kpn,f2flag,fflag)

%直流ゲインの取得

kk1=1;
kk2=1;
kk3=1;

if f2flag==1
    kk1=0;
    kk2=0;
    kk3=0;
    for i=1:fn
        if i==1
            [col,row]=size(tf1_in_si_num);
            for j=1:row
                kk1=kk1+kpn(dq,tf1_in_si_num(1,j));
            end
        elseif i==2
            [col,row]=size(tf2_in_si_num);
            for j=1:row
                kk2=kk2+kpn(dq,tf2_in_si_num(1,j));
            end
        else
            [col,row]=size(tf3_in_si_num);
            for j=1:row
                kk3=kk3+kpn(dq,tf3_in_si_num(1,j));
            end
        end
    end
end

kk=[kk1 kk2 kk3];

b1=tf1(1,:);
a1=tf1(2,:);
b2=tf2(1,:);
a2=tf2(2,:);
b3=tf3(1,:);
a3=tf3(2,:);

[nsi,aggts_in_num]=si_infor_mtrx_for3(fn,all_si_num,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num);
[a,dim_a]=make_mtrx_for3(fn,a1,a2,a3);
[b,dim_b]=make_mtrx_for3(fn,b1,b2,b3);

%インパルス応答波形を基に各数式の次元数を決定
[y]=cal_impulse_all(fn,kk,a,b);
[k_,b]=cal_coefficient(fn,dim_a,dim_b,a,b,f2flag);
[pn]=cal_dim_partv2(fn,dim,dim_a,y);

for i=1:fn
    if pn(1,i)==1
        disp("1次元の伝達関数があります")
    end
end
%平衡打ち切り法
if f2flag ==1
    %FW機能に関する数式モデルのみ直流ゲインの維持
    [Ate_,Bte_,jte,newpn]=hankel_apx_DC(fn,pn,a,b,fflag);
else
    [Ate_,Bte_,jte,newpn]=hankel_apx_fnoDC(fn,pn,a,b,fflag);
end

%それぞれの数式モデルを足し合わせ
[a,b,k_]=tf_agg(fn,newpn,jte,Ate_,Bte_,k_,f2flag);
if f2flag==1
    [kpn]=update_kp(fn,dq,nsi,k_,kpn);
end
end
