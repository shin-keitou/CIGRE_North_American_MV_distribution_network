function[mathcell]=sys_math2cell(dvd,dvq,df1,df2,qvd,qvq,qf1,qf2,kpfw)
mathcell = cell(3,4);
mathcell{1,1} = dvd;
mathcell{1,2} = dvq;
mathcell{1,3} = df1;
mathcell{1,4} = df2;
mathcell{2,1} = qvd;
mathcell{2,2} = qvq;
mathcell{2,3} = qf1;
mathcell{2,4} = qf2;
% mathcell{3,1} = id0;
% mathcell{3,2} = iq0;
% mathcell{3,3} = kpfw;
end



