function[mathcell,kpn]=each_math_agg(fn,dim,idvd_1,idvd_2,idvd_3,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,dq,kpd,f2flag,fflag)

if sum(idvd_1(1,:))==0 && sum(idvd_2(1,:))==0 && sum(idvd_3(1,:))==0
    dvdn=idvd_1(1,:);
    dvdd=idvd_1(2,:);
    kpn = kpd;
elseif sum(idvd_1(1,:))==0 && sum(idvd_2(1,:))==0
    dvdn=idvd_3(1,:);
    dvdd=idvd_3(2,:);
    kpn = kpd;
elseif sum(idvd_2(1,:))==0 && sum(idvd_3(1,:))==0
    dvdn=idvd_1(1,:);
    dvdd=idvd_1(2,:);
    kpn = kpd;
elseif sum(idvd_1(1,:))==0 && sum(idvd_3(1,:))==0
    dvdn=idvd_2(1,:);
    dvdd=idvd_2(2,:);
    kpn = kpd;
elseif sum(idvd_1(1,:))==0
    fn=2;
    [dvdd,dvdn,kpn]=fw_si_agg_each_test(fn,dim,idvd_2,idvd_3,tf2_in_si_num,tf3_in_si_num,all_si_num,dq,kpd,f2flag,fflag);
elseif sum(idvd_2(1,:))==0
    fn=2;
    [dvdd,dvdn,kpn]=fw_si_agg_each_test(fn,dim,idvd_1,idvd_3,tf1_in_si_num,tf3_in_si_num,all_si_num,dq,kpd,f2flag,fflag);
elseif sum(idvd_3(1,:))==0
    fn=2;
    [dvdd,dvdn,kpn]=fw_si_agg_each_test(fn,dim,idvd_1,idvd_2,tf1_in_si_num,tf2_in_si_num,all_si_num,dq,kpd,f2flag,fflag);
else
    [dvdd,dvdn,kpn]=fw_si_agg_each_test_for3(fn,dim,idvd_1,idvd_2,idvd_3,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,dq,kpd,f2flag,fflag);
end

mathcell={[dvdn;dvdd]};

end