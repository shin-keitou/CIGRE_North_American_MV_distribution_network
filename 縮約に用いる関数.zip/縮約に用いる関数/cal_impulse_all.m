function[y]=cal_impulse_all(fn,kk,a,b)
y=zeros(1,fn);
y_all=0;
%各伝達関数のインパルス応答エネルギーとその総和の計算
for i=1:fn
    [y_]=cal_impulse(kk(:,i),a(i,:),b(i,:));
    y(1,i)=y_;
end

