function[vdd,vdq,f1d,f2d,vqd,vqq,f1q,f2q]=fw_ibr_math(Pnom,vinv,lfl,rfl,cfl,kp,kid,kiq,vd0,posi,num_si)
%GFLインバータ数式モデル

zbase=((vinv)^2)/Pnom;
ad=zeros(3,3);
bd=zeros(3,3);

aq=zeros(3,3);
bq=zeros(3,3);

ad(1,1)=lfl/zbase;
ad(1,2)=kp+rfl/zbase;
ad(1,3)=kid;
ad(2,:)=ad(1,:);
ad(3,:)=ad(1,:);
ad(2,:)=ad(1,:);
aq(1,1:2)=ad(1,1:2);
aq(1,3)=kiq;
aq(2,:)=aq(1,:);
aq(3,:)=aq(1,:);

bd(1,1)=0;
bd(1,1)=-1*rfl/zbase*cfl/zbase;
bd(1,2)=-vd0^2-posi*kp;
bd(1,3)=-posi*kid;
bd(3,2)=kp;
bd(3,3)=kid;
bq(2,1)=0;
bq(2,2)=-1;

vdd=[-1*num_si*bd(1,:);ad(1,:)];
vdq=[-1*num_si*bd(2,:);ad(1,:)];
f1d=[-1*num_si*bd(2,:);ad(1,:)];
f2d=[bd(3,:);ad(1,:)];
vqd=[-1*num_si*bq(1,:);aq(1,:)];
vqq=[-1*num_si*bq(2,:);aq(1,:)];
f1q=[-1*num_si*bq(3,:);aq(1,:)];
f2q=[bq(3,:);aq(1,:)];

%極の確認用
% roots(ad(1,:));

end