function[A_,B_,j,newpn]=hankel_apx(fn,pn,a,b)
j=ones(1,fn);
A_=zeros(fn,max(pn)+1);
B_=zeros(fn,max(pn)+1);
newpn=pn;
for i=1:fn
    if pn(1,i)>0        
        tranfun=tf(b(i,:),a(i,:));%(分子，分母)
        opts = balredOptions('Offset',0.0001,'StateProjection','MatchDC');
        opts = balredOptions('Offset',0.1,'StateProjection','MatchDC');
        opts = balredOptions('Offset',0.01,'StateProjection','MatchDC');
        opts = balredOptions('Offset',0.01,'StateProjection','MatchDC','TimeIntervals',[0 1]);
        rsys=balred(tranfun,pn(1,i),opts);
        [num,den] = tfdata(rsys);
        Bk_=cell2mat(num);
        Ak_=cell2mat(den);
        [row col]=size(Ak_);
        if max(pn)==pn(1,i)
            if pn(1,i)>(col-1)
                A_(i,(pn(1,i)-(col-1))+1:max(pn)+1)=Ak_;
                B_(i,(pn(1,i)-(col-1))+1:max(pn)+1)=Bk_;
                newpn(1,i)=col-1;
            else
                A_(i,:)=Ak_;
                B_(i,:)=Bk_;
            end
        else
            newpn(1,i)=col-1;
            insert_zeroA=zeros(1,max(pn)-newpn(1,i));
            insert_zeroB=zeros(1,max(pn)-newpn(1,i));
            A_(i,:)=[insert_zeroA Ak_];
            B_(i,:)=[insert_zeroB Bk_];            
        end
        j(1,i)=0;%値がある場合は0
        clear Ak_ Bk_
    end
end
difpn=max(pn)-max(newpn);
A_=A_(:,difpn+1:(max(pn)+1));
B_=B_(:,difpn+1:(max(pn)+1));
% box_A_=A_;
% box_B_=B_;
% A_=zeros(fn,max(newpn)+1);
% B_=zeros(fn,max(newpn)+1);
% [row,col]=size(box_A_);
% for i=1:row
%     A_=box_A_(i,difpn+1:(max(pn)+1));
%     B_=box_B_(i,difpn+1:(max(pn)+1));
% end

