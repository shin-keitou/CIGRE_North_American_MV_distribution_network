function[kpn]=update_kp(fn,dq,nsi,k_,kp)
for i=1:fn
    si_num=find(nsi(i,:));
    [row col]=size(si_num);
    for j=1:col
%         kp
%         si_num(1,j)
%         k_(1,i)
%         kp(dq,si_num(1,j))
        kp(dq,si_num(1,j))=kp(dq,si_num(1,j))*k_(1,i);
    end
end
kpn=kp;
end
