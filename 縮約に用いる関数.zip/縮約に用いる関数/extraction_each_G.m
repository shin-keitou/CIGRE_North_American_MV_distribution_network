function[vdvd,vdvq,vdf1,vdf2,vqvd,vqvq,vqf1,vqf2,idvd,idvq,idf1,idf2,iqvd,iqvq,iqf1,iqf2]=extraction_each_G(Trs)
% for i=1:4
    for i=1:4
        Ans=Trs(i,1);
        [N2,D2,cd]=trsf_make(Ans);
        vd=zeros(2,cd);
        nrmlz=D2(1,cd);
        vd=[N2/nrmlz;D2/nrmlz];
        
        Ans=Trs(i,2);
        [N2,D2,cd]=trsf_make(Ans);
        vq=zeros(2,cd);
        nrmlz=D2(1,cd);
        vq=[N2/nrmlz;D2/nrmlz];
        
        Ans=Trs(i,3);
        [N2,D2,cd]=trsf_make(Ans);
        f1=zeros(2,cd);
        nrmlz=D2(1,cd);
        f1=[N2/nrmlz;D2/nrmlz];
        
        Ans=Trs(i,4);
        [N2,D2,cd]=trsf_make(Ans);
        f2=zeros(2,cd);
        nrmlz=D2(1,cd);
        f2=[N2/nrmlz;D2/nrmlz];
        if i==1
            vdvd=vd;
            vdvq=vq;
            vdf1=f1;
            vdf2=f2;
        elseif i==2
            vqvd=vd;
            vqvq=vq;
            vqf1=f1;
            vqf2=f2;
        elseif i==3
            idvd=vd;
            idvq=vq;
            idf1=f1;
            idf2=f2;
        else
            iqvd=vd;
            iqvq=vq;
            iqf1=f1;
            iqf2=f2;
        end
    end
% end
end