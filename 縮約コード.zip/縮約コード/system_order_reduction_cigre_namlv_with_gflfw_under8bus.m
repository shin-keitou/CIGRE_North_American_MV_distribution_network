
%matpower計算結果から定常状態値やインピーダンス情報を取得
line_mtrx = result_rpe.branch(:,3:4);
bus_vmag = result_rpe.bus(:,8);
bus_vphase = result_rpe.bus(:,9)/(180/pi);
bus_p = result_rpe.bus(:,3);
bus_q = result_rpe.bus(:,4);
%matpowerはMW単位なので10MW単位に変更
Pz_pu=bus_p(1:11,1)/10;
Qz_pu=bus_q(1:11,1)/10;
Pibr_pu=bus_p(12:18,1)/10;
Qibr_pu=bus_q(12:18,1)/10;

%負荷電圧特性 Z I P
zip_rate = [1 0 0; 1 0 0];
%負荷周波数特性
frate = [0 0];

clear kpfw

%IBR情報
Kp=1;
Kid=300;
Kiq=300;
kpfw_ori = k;

R_SI_pu_red=[0.005,0.005,0.002,0.002,0.002,0.002,0.002];
L_SI_pu_red=[1.05,1.05,1.38,1.15,1.31,1.21,1.00]/(2*pi*rate_freq);

num_ibr=size(R_SI_pu,2);
all_si_num = num_ibr;
kpfw(1,:) = k;
kpfw(2,:)= ones(1,all_si_num);

loadbus_num = transpose([1:11]);
ibr_num = transpose([12:18]);
Pnom1 = 400e3;
Pnom2 = 300e3;
Pbase = 10e6;
vbase = 12.47e3;

%IBR7 数式モデル
num_si = 400e3*3/Pbase;
[vdd_gfl7,vdq_gfl7,f1d_gfl7,f2d_gfl7,vqd_gfl7,vqq_gfl7,f1q_gfl7,f2q_gfl7]=fw_ibr_math(Pnom1,Vinv,L_SI_pu_red(1,7),R_SI_pu_red(1,7),C_SI_pu(1,1),Kp,Kid,Kiq,bus_vmag(18,1),P0(1,7),num_si);

%IBR7と変圧器の合成
rpm=line_mtrx(18,1);
lpm=line_mtrx(18,2)/(2*pi*rate_freq);

vupper_num=11;
vunder_num=18;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

id0 = Pibr_pu(7,1)/bus_vmag(vunder_num,1)*cos(phase_devi);
iq0 = Pibr_pu(7,1)/bus_vmag(vunder_num,1)*sin(phase_devi);

[vdvd_11,vdvq_11,vdf1_11,vdf2_11,vqvd_11,vqvq_11,vqf1_11,vqf2_11,idvd_11,idvq_11,idf1_11,idf2_11,iqvd_11,iqvq_11,iqf1_11,iqf2_11]=ibr_integration_impedance(rate_freq,rpm,lpm,vdd_gfl7,vdq_gfl7,f1d_gfl7,f2d_gfl7,vqd_gfl7,vqq_gfl7,f1q_gfl7,f2q_gfl7,vd0,vq0,id0,iq0);

%極の確認用
% roots(vdvd_11(2,:))

%line 10-11との合成
rpm=line_mtrx(10,1);
lpm=line_mtrx(10,2)/(2*pi*rate_freq);
line_length=1;

vupper_num=10;
vunder_num=11;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

idz0 = Pz_pu(vunder_num,1)/bus_vmag(vunder_num,1);
iqz0 = Qz_pu(vunder_num,1)/bus_vmag(vunder_num,1); 

id0=(id0+idz0)*cos(phase_devi)-(iq0+iqz0)*sin(phase_devi);
iq0=(id0+idz0)*sin(phase_devi)+(iq0+iqz0)*cos(phase_devi);

[vdvd_10,vdvq_10,vdf1_10,vdf2_10,vqvd_10,vqvq_10,vqf1_10,vqf2_10,idvd_10,idvq_10,idf1_10,idf2_10,iqvd_10,iqvq_10,iqf1_10,iqf2_10]=ibr_integration_impedance_withld(rate_freq,Pz_pu(vunder_num,1),Qz_pu(vunder_num,1),zip_rate,frate,rpm,lpm,line_length,idvd_11,idvq_11,idf1_11,idf2_11,iqvd_11,iqvq_11,iqf1_11,iqf2_11,id0,iq0,vd0,vq0,idz0,iqz0);

%ソルバが解きやすいように次元縮約
%dim = 縮約後次元数
dim = 5;
%dim以下の次元にしたい変数がある場合はflagの一行目に1,二行目に所望の次元数を入力
flag = zeros(2,8);
[idvd_10,idvq_10,idf1_10,idf2_10,iqvd_10,iqvq_10,iqf1_10,iqf2_10]=i_reduce_order_hankel_tf_fw(dim,flag,idvd_10,idvq_10,idf1_10,idf2_10,iqvd_10,iqvq_10,iqf1_10,iqf2_10);
step(tf(idf1_10(1,:),idf1_10(2,:)))

%line 9-10との合成
rpm=line_mtrx(9,1);
lpm=line_mtrx(9,2)/(2*pi*rate_freq);
line_length=1;

vupper_num=9;
vunder_num=10;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

idz0 = Pz_pu(vunder_num,1)/bus_vmag(vunder_num,1);
iqz0 = Qz_pu(vunder_num,1)/bus_vmag(vunder_num,1); 

id0=(id0+idz0)*cos(phase_devi)-(iq0+iqz0)*sin(phase_devi);
iq0=(id0+idz0)*sin(phase_devi)+(iq0+iqz0)*cos(phase_devi);

[vdvd_9,vdvq_9,vdf1_9,vdf2_9,vqvd_9,vqvq_9,vqf1_9,vqf2_9,idvd_9,idvq_9,idf1_9,idf2_9,iqvd_9,iqvq_9,iqf1_9,iqf2_9]=ibr_integration_impedance_withld(rate_freq,Pz_pu(vunder_num,1),Qz_pu(vunder_num,1),zip_rate,frate,rpm,lpm,line_length,idvd_10,idvq_10,idf1_10,idf2_10,iqvd_10,iqvq_10,iqf1_10,iqf2_10,id0,iq0,vd0,vq0,idz0,iqz0);

%ソルバが解きやすいように次元縮約
dim = 6;
flag = zeros(2,8);
[idvd_9,idvq_9,idf1_9,idf2_9,iqvd_9,iqvq_9,iqf1_9,iqf2_9]=i_reduce_order_hankel_tf_fw(dim,flag,idvd_9,idvq_9,idf1_9,idf2_9,iqvd_9,iqvq_9,iqf1_9,iqf2_9);

dim = 7;
flag = zeros(2,8);
[vdvd_9,vdvq_9,vdf1_9,vdf2_9,vqvd_9,vqvq_9,vqf1_9,vqf2_9]=i_reduce_order_hankel_tf_fw(dim,flag,vdvd_9,vdvq_9,vdf1_9,vdf2_9,vqvd_9,vqvq_9,vqf1_9,vqf2_9);


%line 8-9と負荷との合成
rpm=line_mtrx(8,1);
lpm=line_mtrx(8,2)/(2*pi*rate_freq);
line_length=1;

vupper_num=8;
vunder_num=9;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

idz0 = Pz_pu(vunder_num,1)/bus_vmag(vunder_num,1);
iqz0 = Qz_pu(vunder_num,1)/bus_vmag(vunder_num,1); 

id0=(id0+idz0)*cos(phase_devi)-(iq0+iqz0)*sin(phase_devi);
iq0=(id0+idz0)*sin(phase_devi)+(iq0+iqz0)*cos(phase_devi);
id08_9 = id0;
iq08_9 = iq0;
[vdvd_8_9,vdvq_8_9,vdf1_8_9,vdf2_8_9,vqvd_8_9,vqvq_8_9,vqf1_8_9,vqf2_8_9,idvd_8_9,idvq_8_9,idf1_8_9,idf2_8_9,iqvd_8_9,iqvq_8_9,iqf1_8_9,iqf2_8_9]=ibr_integration_impedance_withld(rate_freq,Pz_pu(vunder_num,1),Qz_pu(vunder_num,1),zip_rate,frate,rpm,lpm,line_length,idvd_9,idvq_9,idf1_9,idf2_9,iqvd_9,iqvq_9,iqf1_9,iqf2_9,id0,iq0,vd0,vq0,idz0,iqz0);
[math_sys1]  = sys_math2cell(idvd_8_9,idvq_8_9,idf1_8_9,idf2_8_9,iqvd_8_9,iqvq_8_9,iqf1_8_9,iqf2_8_9);

%ソルバが解きやすいように次元縮約
dim = 7;
flag = zeros(2,8);
[vdvd_8_9,vdvq_8_9,vdf1_8_9,vdf2_8_9,vqvd_8_9,vqvq_8_9,vqf1_8_9,vqf2_8_9]=i_reduce_order_hankel_tf_fw(dim,flag,vdvd_8_9,vdvq_8_9,vdf1_8_9,vdf2_8_9,vqvd_8_9,vqvq_8_9,vqf1_8_9,vqf2_8_9);

%IBR6 数式モデル導出
num_si = 400e3*2/Pbase;
[vdd_gfl6,vdq_gfl6,f1d_gfl6,f2d_gfl6,vqd_gfl6,vqq_gfl6,f1q_gfl6,f2q_gfl6]=fw_ibr_math(Pnom1,Vinv,L_SI_pu_red(1,6),R_SI_pu_red(1,6),C_SI_pu(1,1),Kp,Kid,Kiq,bus_vmag(17,1),P0(1,6),num_si);

%IBR6と変圧器の合成
rpm=line_mtrx(17,1);
lpm=line_mtrx(17,2)/(2*pi*rate_freq);

vupper_num=7;
vunder_num=17;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

id0 = Pibr_pu(6,1)/bus_vmag(vunder_num,1)*cos(phase_devi);
iq0 = Pibr_pu(6,1)/bus_vmag(vunder_num,1)*sin(phase_devi);

[vdvd_7,vdvq_7,vdf1_7,vdf2_7,vqvd_7,vqvq_7,vqf1_7,vqf2_7,idvd_7,idvq_7,idf1_7,idf2_7,iqvd_7,iqvq_7,iqf1_7,iqf2_7]=ibr_integration_impedance(rate_freq,rpm,lpm,vdd_gfl6,vdq_gfl6,f1d_gfl6,f2d_gfl6,vqd_gfl6,vqq_gfl6,f1q_gfl6,f2q_gfl6,vd0,vq0,id0,iq0);

%line 7-8と負荷との合成
rpm=line_mtrx(7,1);
lpm=line_mtrx(7,2)/(2*pi*rate_freq);
line_length=1;

vupper_num=8;
vunder_num=7;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

idz0 = Pz_pu(vunder_num,1)/bus_vmag(vunder_num,1);
iqz0 = Qz_pu(vunder_num,1)/bus_vmag(vunder_num,1); 

id0=(id0+idz0)*cos(phase_devi)-(iq0+iqz0)*sin(phase_devi);
iq0=(id0+idz0)*sin(phase_devi)+(iq0+iqz0)*cos(phase_devi);
id08_7 = id0;
iq08_7 = iq0;
[vdvd_8_7,vdvq_8_7,vdf1_8_7,vdf2_8_7,vqvd_8_7,vqvq_8_7,vqf1_8_7,vqf2_8_7,idvd_8_7,idvq_8_7,idf1_8_7,idf2_8_7,iqvd_8_7,iqvq_8_7,iqf1_8_7,iqf2_8_7]=ibr_integration_impedance_withld(rate_freq,Pz_pu(vunder_num,1),Qz_pu(vunder_num,1),zip_rate,frate,rpm,lpm,line_length,idvd_7,idvq_7,idf1_7,idf2_7,iqvd_7,iqvq_7,iqf1_7,iqf2_7,id0,iq0,vd0,vq0,idz0,iqz0);
[math_sys2]  = sys_math2cell(idvd_8_7,idvq_8_7,idf1_8_7,idf2_8_7,iqvd_8_7,iqvq_8_7,iqf1_8_7,iqf2_8_7);

%IBR6 数式モデル導出
num_si = 300e3*2/Pbase;
[vdd_gfl5,vdq_gfl5,f1d_gfl5,f2d_gfl5,vqd_gfl5,vqq_gfl5,f1q_gfl5,f2q_gfl5]=fw_ibr_math(Pnom1,Vinv,L_SI_pu_red(1,5),R_SI_pu_red(1,5),C_SI_pu(1,1),Kp,Kid,Kiq,bus_vmag(16,1),P0(1,5),num_si);

%IBR6と変圧器の合成
rpm=line_mtrx(15,1);
lpm=line_mtrx(15,2)/(2*pi*rate_freq);

vupper_num=8;
vunder_num=16;
phase_devi=bus_vphase(vunder_num,1)-bus_vphase(vupper_num,1);
vd0=bus_vmag(vupper_num,1)*cos(phase_devi);
vq0=bus_vmag(vupper_num,1)*sin(phase_devi);

id0 = Pibr_pu(5,1)/bus_vmag(vunder_num,1)*cos(phase_devi);
iq0 = Pibr_pu(5,1)/bus_vmag(vunder_num,1)*sin(phase_devi);

id08_16 = id0;
iq08_16 = iq0;

[vdvd_8_16,vdvq_8_16,vdf1_8_16,vdf2_8_16,vqvd_8_16,vqvq_8_16,vqf1_8_16,vqf2_8_16,idvd_8_16,idvq_8_16,idf1_8_16,idf2_8_16,iqvd_8_16,iqvq_8_16,iqf1_8_16,iqf2_8_16]=ibr_integration_impedance(rate_freq,rpm,lpm,vdd_gfl5,vdq_gfl5,f1d_gfl5,f2d_gfl5,vqd_gfl5,vqq_gfl5,f1q_gfl5,f2q_gfl5,vd0,vq0,id0,iq0);
[math_sys3]  = sys_math2cell(idvd_8_16,idvq_8_16,idf1_8_16,idf2_8_16,iqvd_8_16,iqvq_8_16,iqf1_8_16,iqf2_8_16);

% math model aggregation
%集約後次数
dim=40;
%数式モデル数
fn=3;
%各数式モデルに含まれているIBRの番号
tf1_ibr_num=7;%ibrnum
tf2_ibr_num=6;%ibrnum
tf3_ibr_num=5;%ibrnum
tf1_in_si_num=[tf1_ibr_num]; 
tf2_in_si_num=[tf2_ibr_num]; 
tf3_in_si_num=[tf3_ibr_num]; 
[idvd_8,idvq_8,idf1_8,idf2_8,iqvd_8,iqvq_8,iqf1_8,iqf2_8,kpfw]=fw_si_agg3(fn,dim,math_sys1,math_sys2,math_sys3,tf1_in_si_num,tf2_in_si_num,tf3_in_si_num,all_si_num,kpfw);

%ソルバが解けなかったら次元縮約
% dim = 7;
% [idvd_8,idvq_8,idf1_8,idf2_8,iqvd_8,iqvq_8,iqf1_8,iqf2_8]=i_reduce_order_hankel_tf_fw(dim,flag,idvd_8,idvq_8,idf1_8,idf2_8,iqvd_8,iqvq_8,iqf1_8,iqf2_8);
