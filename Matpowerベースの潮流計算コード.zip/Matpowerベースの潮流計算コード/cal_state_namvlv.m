
%全負荷電圧1puのときの消費電力とおいて潮流計算で初期解を得る
mpc = loadcase('pf_mat_namvlv');
result_ini = runpf(mpc);

%定インピーダンス負荷の電圧特性をエクセルから取得
bus_data_all = readmatrix('cigre_namvlv_busdata_for_check.xlsx');
load_z_data = bus_data_all(1:11,15:16);
count = 0;
P_error_check = 1;
Q_error_check = 1;

%各負荷の電圧値から新な消費電力を計算し，前回との消費電力の誤差が十分小さくなるまで繰り返し計算。
while P_error_check > 1e-6 && Q_error_check > 1e-6
    if count == 0
        cal_bus_vdata = result_ini.bus(1:11,8);
        cal_bus_PQdata = result_ini.bus(1:11,3:4);
    else
        cal_bus_vdata = result_rpe.bus(1:11,8);
        cal_bus_PQdata = result_rpe.bus(1:11,3:4);
    end
    
    constantZ_loadPQ = zeros(11,2);
    for i = 1 : 11
        constantZ_loadPQ(i,1) = cal_bus_vdata(i,1)^2 / load_z_data(i,1);
        constantZ_loadPQ(i,2) = cal_bus_vdata(i,1)^2 / load_z_data(i,2);
    end
    
    PQ_error = cal_bus_PQdata - constantZ_loadPQ;
    P_error_check = max(abs(PQ_error(:,1)));
    Q_error_check = max(abs(PQ_error(:,2)));
    bus_data_ini = readmatrix('cigre_namvlv_busdata.xlsx');
    bus_data_repeat_cal = bus_data_ini;
    bus_data_repeat_cal(1:11,3:4) = constantZ_loadPQ;
    writematrix(bus_data_repeat_cal, 'cigre_namvlv_busdata_rep.xlsx');
    mpc = loadcase('pf_mat_namvlv_2');
    result_rpe = runpf(mpc);
    count = count + 1;
end

