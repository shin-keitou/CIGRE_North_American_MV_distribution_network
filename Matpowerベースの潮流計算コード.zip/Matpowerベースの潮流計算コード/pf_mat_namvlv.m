function mpc = pf_mat_namvlv

NR_bus = readmatrix('cigre_namvlv_busdata.xlsx');


NR_branch = readmatrix('cigre_namvlv_linedata.xlsx'); 


NR_gen = readmatrix('cigre_namvlv_gendata.xlsx'); 

%   MATPOWER

%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 10;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
% mpc.bus = [
% 	1	3	0	0	0	0	1	1	0	345	1	1.1	0.9;
% 	2	2	0	0	0	0	1	1	0	345	1	1.1	0.9;
% 	3	2	0	0	0	0	1	1	0	345	1	1.1	0.9;
% 	4	1	0	0	0	0	1	1	0	345	1	1.1	0.9;
% 	5	1	90	30	0	0	1	1	0	345	1	1.1	0.9;
% 	6	1	0	0	0	0	1	1	0	345	1	1.1	0.9;
% 	7	1	100	35	0	0	1	1	0	345	1	1.1	0.9;
% 	8	1	0	0	0	0	1	1	0	345	1	1.1	0.9;
% 	9	1	125	50	0	0	1	1	0	345	1	1.1	0.9;
% ];
mpc.bus=NR_bus;
%% generator data
mpc.gen =NR_gen;
%% branch data

mpc.branch=NR_branch;
%%-----  OPF Data  -----%%
%% generator cost data

% mpc.gencost =NR_gen;
