function mpc = pf_mat_namvlv_2

NR_bus = readmatrix('cigre_namvlv_busdata_rep.xlsx');

NR_branch = readmatrix('cigre_namvlv_linedata.xlsx'); 

NR_gen = readmatrix('cigre_namvlv_gendata.xlsx'); 

%   MATPOWER

%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 10;

%% bus data

mpc.bus=NR_bus;
%% generator data

mpc.gen =NR_gen;
%% branch data

mpc.branch=NR_branch;
%%-----  OPF Data  -----%%
%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
% mpc.gencost = [
% 	2	1500	0	3	0.11	5	150;
% 	2	2000	0	3	0.085	1.2	600;
% 	2	3000	0	3	0.1225	1	335;
% ];
% mpc.gencost =NR_gen;
